# Foxo.Club Health Companion App

## Overview
This project is a production–grade FastAPI application for Foxo.Club, an AI–based health companion platform. It provides:
- **Stateless Authentication & Role–Based Authorization** using JWT.
- **PDF Report Upload**: Registered clients can upload health checkup PDFs; files are stored in AWS S3 with a custom path.
- **Health Parameter Extraction**: Extracts and normalizes health parameters from reports (simulated) and stores key–value pairs in DynamoDB.
- **Admin Portal**: Internal endpoints for admin users to review clients, reports, and approve/reject extracted health parameters.

## Design Principles & Patterns
- **OOP & SOLID**:  
  - Each module is responsible for one concern (e.g., `auth`, `pdf`, `admin`).
  - Dependency Injection is used for database sessions and JWT verification.
- **Design Patterns**:  
  - **Factory Pattern** in JWT creation.
  - **Repository Pattern** in CRUD operations.
  - **Singleton Pattern** for managing the DB connection per request.
- **RESTful API Principles**:  
  - Consistent endpoint naming, proper HTTP status codes, and stateless architecture.

## Deployment
- **Dockerized**: Build with `docker build -t foxoclub-app .`
- **Run Locally**:  
  ```bash
  docker run -p 8000:8000 --env-file .env foxoclub-app
  ```
- **Designed for deployment on AWS services such as Elastic Beanstalk, ECS, or EKS.**

## Testing the Application Locally
- Clone the repository and create a virtual environment.
- Copy .env.example to .env and fill in credentials (use test instances).
- Install dependencies:
  ```bash
  pip install -r requirements.txt
  ```
- Run the application:
  ```bash
  uvicorn app.main:app --reload
  ```
- Run the application:
  - Signup: http://127.0.0.1:8000/auth/signup
  - Login: http://127.0.0.1:8000/auth/login
  - Admin endpoints: http://127.0.0.1:8000/admin/clients
