# app/db/models.py
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text, Enum, Float
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
import enum

Base = declarative_base()

# User roles
class UserRole(enum.Enum):
    client = "client"
    admin = "admin"
    superuser = "superuser"

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    phone_number = Column(String, unique=True, index=True, nullable=True)  # for clients
    username = Column(String, unique=True, index=True, nullable=True)      # for admin users
    hashed_password = Column(String, nullable=False)
    role = Column(Enum(UserRole), default=UserRole.client, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

# Report processing status
class ReportStatus(enum.Enum):
    pending = "pending"
    success = "success"
    failure = "failure"

class Report(Base):
    __tablename__ = "reports"
    id = Column(Integer, primary_key=True, index=True)
    client_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    s3_path = Column(String, nullable=False)
    uploaded_at = Column(DateTime, default=datetime.utcnow)
    processing_status = Column(Enum(ReportStatus), default=ReportStatus.pending)
    report_unique_id = Column(String, nullable=False)

# Health parameter status
class HealthParameterStatus(enum.Enum):
    pending = "pending"
    approved = "approved"
    rejected = "rejected"

class HealthParameter(Base):
    __tablename__ = "health_parameters"
    id = Column(Integer, primary_key=True, index=True)
    report_id = Column(Integer, ForeignKey("reports.id"), nullable=False)
    parameter_name = Column(String, nullable=False)
    value = Column(String, nullable=True)
    unit = Column(String, nullable=True)
    reference_range = Column(String, nullable=True)
    method = Column(String, nullable=True)
    status = Column(Enum(HealthParameterStatus), default=HealthParameterStatus.pending)
    created_at = Column(DateTime, default=datetime.utcnow)
    action_timestamp = Column(DateTime, nullable=True)
    approved_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    remarks = Column(Text, nullable=True)
    map_to_existing = Column(String, default="None")
